1. Wählen Sie die Hauptdatei_GUI, um die Datei zu starten.
2. Installieren Sie die relevanten Bib und Moduls entsprechend dem Import, bevor Sie die Datei starten. z.B. owlready2, graphviz, etc.