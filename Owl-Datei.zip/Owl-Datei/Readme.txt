Pizza.owl hat in der Projekt die Implementierung der GUI benutzt. 
Pizza.owl wurde von uns selbst erstellt und wurde in Ontologie Pflegen verwendet.
travel.owl kann in der "OpenFile"der GUI als Test-Datei verwendet werden.